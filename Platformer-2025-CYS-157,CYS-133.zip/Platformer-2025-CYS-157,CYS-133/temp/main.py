import os
import random
import math
import pygame
from os import listdir
from os.path import isfile, join
pygame.init()

pygame.display.set_caption("Platformer")

WIDTH, HEIGHT = 1000, 800
FPS = 60
PLAYER_VEL = 5

window = pygame.display.set_mode((WIDTH, HEIGHT))

def main(window):
    clock = pygame.time.Clock()
    background, bg_image = get_background("Blue.png")
    block_size = 96
    player = Player(100, 100, 50, 50)
    fire = Fire(300, HEIGHT - block_size - 64, 16, 32)
    fire.on()
    LEVEL_LENGTH = 20
    floor = [Block(i * block_size, HEIGHT - block_size, block_size)
            for i in range(LEVEL_LENGTH)]
    objects = [*floor, Block(0, HEIGHT - block_size * 2, block_size),
               Block(block_size * 3, HEIGHT - block_size * 4, block_size), fire]
    for _ in range(8):
        x = random.randint(3, LEVEL_LENGTH-2) * block_size
        y = HEIGHT - block_size - 64
        objects.append(RandomObject(x, y))
    coins = []
    NUM_COINS = 20
    for _ in range(NUM_COINS):
        placed = False
        attempts = 0
        while not placed and attempts < 50:
            attempts += 1
            x = random.randint(1, LEVEL_LENGTH - 1) * block_size
            y = HEIGHT - block_size - 96
            coin_rect = pygame.Rect(x, y, 32, 32)
            overlap = False
            for obj in objects:
                if obj.name == "random" and coin_rect.colliderect(obj.rect.inflate(32, 32)):
                    overlap = True
                    break
            if not overlap:
                coin = Coin(x, y)
                objects.append(coin)
                coins.append(coin)
                placed = True
        finish = Finish(LEVEL_LENGTH * block_size - 128, HEIGHT - block_size - 96)
        objects.append(finish)
    offset_x = 0
    scroll_area_width = 200
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and player.jump_count < 2:
                    player.jump()
        player.loop(FPS)
        fire.loop()
        handle_move(player, objects)
        for coin in coins[:]:
            if player.rect.colliderect(coin.rect):
                player.score += 1
                coins.remove(coin)
                objects.remove(coin)
        if player.rect.colliderect(finish.rect):
            game_over(player, win=True)
        if player.rect.top > HEIGHT:
            lose_life(player)
        if ((player.rect.right - offset_x >= WIDTH - scroll_area_width) and player.x_vel > 0) or ((player.rect.left - offset_x <= scroll_area_width) and player.x_vel < 0):
            offset_x += player.x_vel
        offset_x = max(0, min(offset_x, LEVEL_LENGTH * block_size - WIDTH))
        draw(window, background, bg_image, player, objects, offset_x)
    pygame.quit()
    quit()

if __name__ == "__main__":
    main(window)
