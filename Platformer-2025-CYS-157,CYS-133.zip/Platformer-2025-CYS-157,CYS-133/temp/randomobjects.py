class RandomObject(Object):
    def __init__(self, x, y, width=64, height=64):
        super().__init__(x, y, width, height, "random")
        obj_path = join("assets", "Objects", "random.png")
        if os.path.exists(obj_path):
            self.image = pygame.image.load(obj_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (width, height))
        self.mask = pygame.mask.from_surface(self.image)