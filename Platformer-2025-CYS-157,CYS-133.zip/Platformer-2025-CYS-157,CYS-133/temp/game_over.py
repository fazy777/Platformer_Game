def game_over(player, win=False):
    font = pygame.font.SysFont(None, 72)
    small_font = pygame.font.SysFont(None, 36)
    if win:
        text = font.render("Game Over - You Win!", True, (0, 255, 0))
    else:
        text = font.render("Game Over - You Lose!", True, (255, 0, 0))
    score_text = small_font.render(f"Final Score: {player.score}", True, (255, 215, 0))
    restart_text = small_font.render("Press R to Restart or Q to Quit", True, (255, 255, 255))
    run = True
    while run:
        window.fill((0, 0, 0))
        window.blit(text, (WIDTH//2 - text.get_width()//2, HEIGHT//3))
        window.blit(score_text, (WIDTH//2 - score_text.get_width()//2, HEIGHT//2))
        window.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, HEIGHT//2 + 50))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    main(window)
                if event.key in [pygame.K_q, pygame.K_ESCAPE]:
                    run = False
                    pygame.quit()
                    quit()