class Coin(Object):
    def __init__(self, x, y):
        super().__init__(x, y, 32, 32, "coin")
        coin_path = join("assets", "Items", "coin.png")
        if os.path.exists(coin_path):
            self.image = pygame.image.load(coin_path).convert_alpha()
        else:
            self.image.fill((255, 223, 0))
        self.mask = None
    def draw(self, win, offset_x):
        win.blit(self.image, (self.rect.x - offset_x, self.rect.y))
