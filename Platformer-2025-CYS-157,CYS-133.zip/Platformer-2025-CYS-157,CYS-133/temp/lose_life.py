def lose_life(player):
    player.lives -= 1
    if player.lives > 0:
        player.rect.topleft = (player.spawn_x, player.spawn_y)
        player.x_vel = 0
        player.y_vel = 0
    else:
        game_over(player, win=False)